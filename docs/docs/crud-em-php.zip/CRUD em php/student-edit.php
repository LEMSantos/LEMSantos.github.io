<?php
	require 'db.php';

	$student_id = null;
	$student = null;

	if(isset($_GET['id'])) {
		$student_id = $_GET['id'];
		$student = $db->get($student_id);
	}
?>

<!doctype html>
<html lang="pt">
  <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Estudante - CRUD</title>

	<link
		href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
		rel="stylesheet"
		integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
		crossorigin="anonymous"
	>
  </head>

  <body>
	<div class="container mt-5">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<h4>
							Editar Estudante
							<a href="index.php" class="btn btn-danger float-end">
								Voltar
							</a>
						</h4>
					</div>

					<div class="card-body">
						<?php if($student): ?>
							<form action="crud-code.php" method="POST">
								<input type="hidden" name="id" value="<?= $student_id ?>">

								<div class="mb-3">
									<label>Nome</label>
									<input
										type="text"
										name="name"
										value="<?= $student['name'] ?>"
										class="form-control"
									>
								</div>

								<div class="mb-3">
									<label>E-mail</label>
									<input
										type="email"
										name="email"
										value="<?= $student['email'] ?>"
										class="form-control"
									>
								</div>

								<div class="mb-3">
									<label>Telefone</label>
									<input
										type="text"
										name="phone"
										value="<?= $student['phone'] ?>"
										class="form-control"
									>
								</div>

								<div class="mb-3">
									<label>Curso</label>
									<input
										type="text"
										name="course"
										value="<?= $student['course'] ?>"
										class="form-control"
									>
								</div>

								<div class="mb-3">
									<button type="submit" name="update_student" class="btn btn-primary">
										Atualizar estudante
									</button>
								</div>
							</form>
						<?php else: ?>
							<h4>Esse estudante não foi encontrado!</h4>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>


	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
		crossorigin="anonymous"
	></script>
  </body>
</html>
