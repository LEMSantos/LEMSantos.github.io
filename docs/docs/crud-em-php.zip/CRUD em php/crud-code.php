<?php

session_start();

require 'db.php';

if(isset($_POST['save_student']))
{
	$payload = [
		'name' => $_POST['name'],
		'email' => $_POST['email'],
		'phone' => $_POST['phone'],
		'course' => $_POST['course'],
	];

	$query_run = $db->put($payload);

	$_SESSION['message'] = 'Falha na criação do estudante';

	if($query_run) {
		$_SESSION['message'] = 'Estudante criado com sucesso';
	}

	header('Location: index.php');
	exit(0);
}

if(isset($_POST['update_student']))
{
	$payload = [
		'name' => $_POST['name'],
		'email' => $_POST['email'],
		'phone' => $_POST['phone'],
		'course' => $_POST['course'],
	];

	$query_run = $db->replace($_POST['id'], $payload);

	$_SESSION['message'] = 'Falha na atualização do estudante';

	if ($query_run) {
		$_SESSION['message'] = 'Estudante atualizado com sucesso';
	}

	header("Location: index.php");
	exit(0);
}

if(isset($_POST['delete_student']))
{
	$student_id = $_POST['delete_student'];
	$query_run = $db->remove($student_id);

	$_SESSION['message'] = 'Falha ao deletar o estudante';

	if ($query_run) {
		$_SESSION['message'] = 'Estudante deletado com sucesso';
	}

	header("Location: index.php");
	exit(0);
}
