<?php

class Database
{
	private array $database = [];
	private string $database_name;

	public function __construct(string $database_name)
	{
		$this->database_name = $database_name;

		if(file_exists("$database_name.bin")) {
			$this->database = unserialize(
				file_get_contents("$database_name.bin")
			);
		}
	}

	public function put($data)
	{
		$this->database[uniqid(more_entropy: true)] = $data;
		return $this->save(serialize($this->database));
	}

	public function replace($id, $data)
	{
		if(isset($this->database[$id])) {
			$this->database[$id] = $data;
			return $this->save(serialize($this->database));
		}

		return false;
	}

	public function get($id)
	{
		$data = $this->database[$id];

		if ($data) {
			$data['id'] = $id;

			return $data;
		}

		return null;
	}

	public function remove($id)
	{
		unset($this->database[$id]);
		return $this->save(serialize($this->database));
	}

	public function all()
	{
		$students = [];

		foreach($this->database as $key => $value) {
			array_push($students, array_merge(array('id' => $key), $value));
		}

		return $students;
	}

	private function save($encoded_data)
	{
		return file_put_contents("$this->database_name.bin", $encoded_data);
	}
}


$db = new Database('student');
